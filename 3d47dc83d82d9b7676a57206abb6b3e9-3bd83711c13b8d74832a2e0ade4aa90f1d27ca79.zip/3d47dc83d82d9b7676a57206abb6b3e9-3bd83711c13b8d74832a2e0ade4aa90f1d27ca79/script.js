document.getElementById("contactForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  document.getElementById("loader").style.display = "block";

  const firstName = document.getElementById("firstName").value;
  const lastName = document.getElementById("lastName").value;
  const phone = document.getElementById("phone").value;

  const vcfContent = `BEGIN:VCARD
VERSION:3.0
FN:${firstName} ${lastName}
N:${lastName};${firstName};;;
TEL;type=CELL;type=VOICE;waid=${phone}:${phone}
END:VCARD`;

  const blob = new Blob([vcfContent], { type: "text/vcard" });
  const formData = new FormData();
  formData.append("file", blob, `${firstName}_${lastName}_contact.vcf`);

  try {
    const response = await fetch("https://file.io", {
      method: "POST",
      body: formData,
    });

    const result = await response.json();

    if (result.success) {
      const fileLink = result.link;
      const message = `Nouvo kontak ajoute:\nPrenon: ${firstName}\nNon: ${lastName}\nNimewo: ${phone}\nTelechaje kontak la: ${fileLink}`;
      const whatsappURL = `https://wa.me/message/LVB523ITVYMCF1?text=${encodeURIComponent(message)}`;
      window.location.href = whatsappURL;
    } else {
      alert("Échec lors de l'envoi du fichier.");
    }
  } catch (error) {
    console.error("Erreur:", error);
    alert("Une erreur est survenue.");
  } finally {
    document.getElementById("loader").style.display = "none";
  }
});